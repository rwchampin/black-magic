export { default } from './PreviewTabs';
export type { Tab, PreviewTabsProps } from './types';
